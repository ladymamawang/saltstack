================================================================================
pyecharts-jupyter-installer
================================================================================

.. image:: https://api.travis-ci.org/pyecharts/pyecharts-jupyter-installer.svg?branch=master
   :target: http://travis-ci.org/pyecharts/pyecharts-jupyter-installer

.. image:: https://codecov.io/gh/pyecharts/pyecharts-jupyter-installer/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/pyecharts/pyecharts-jupyter-installer



Installation
================================================================================


You can install pyecharts-jupyter-installer via pip:

.. code-block:: bash

    $ pip install pyecharts-jupyter-installer


or clone it and install it:

.. code-block:: bash

    $ git clone https://github.com/pyecharts/pyecharts-jupyter-installer.git
    $ cd pyecharts-jupyter-installer
    $ python setup.py install

Change log
================================================================================

0.0.2 - 12/02/2018
--------------------------------------------------------------------------------

Updated
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#. Well tested working version



