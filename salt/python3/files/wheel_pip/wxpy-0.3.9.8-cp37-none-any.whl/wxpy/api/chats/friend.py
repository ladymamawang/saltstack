# coding: utf-8
from __future__ import unicode_literals

import logging

from .user import User

logger = logging.getLogger(__name__)


class Friend(User):
    """
    好友对象
    """

    pass
