class TestFriend:
    pass