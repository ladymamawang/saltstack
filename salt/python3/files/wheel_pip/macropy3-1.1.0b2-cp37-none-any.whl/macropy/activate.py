"""Shorthand import to initialize MacroPy"""
import macropy

macropy.activate()
