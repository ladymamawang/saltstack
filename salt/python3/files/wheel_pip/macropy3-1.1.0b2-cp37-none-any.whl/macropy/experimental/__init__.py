"""This directory directly contains a bunch of macros which are less
well-tested and probably unstable, but nonetheless serve as pretty cool
demonstrations of what is possible using MacroPy. Many of them have third
party dependencies which are not installed by default (to avoid bloating the
installing) and need to be installed manually before they can be used."""